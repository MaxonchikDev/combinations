from setuptools import setup

setup(name='combinations',
      version='1.1',
      description='Helps to find combinations',
      packages=['combinations'],
      author_email='maximsavaldin@gmail.com',
      zip_safe=False)
